# Brain_Tumer-ML
 <b>In this I have used Data directory flow, Convolutional Neural Network from Keras and Sequential Model along with tensorflow for creation of our model. As a result we will be able to predict accurately whether the MRI image shows any tumour or not.
